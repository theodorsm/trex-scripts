This folder contains the results for UDP messages
